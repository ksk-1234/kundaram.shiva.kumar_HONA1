package com.accenture.ltt.HON1.HON1;
public class CreditCardPayment extends Payment implements MyCard {
	 
    private String cardNumber;
 
    public CreditCardPayment(double amount, String cardNumber) {
        super(amount);
        this.cardNumber = cardNumber;
    }
 
    @Override
    public void processPayment() {
        validateCard();
        chargeCard();
        System.out.println("Credit Card Payment Processed: " + getAmount());
    }
 
    public void chargeCard() {
        System.out.println("Charging credit card " + cardNumber + " an amount of" + getAmount());
    }

    public void validateCard() {
        System.out.println("Validating credit card of number" + cardNumber);
    }
 
}
