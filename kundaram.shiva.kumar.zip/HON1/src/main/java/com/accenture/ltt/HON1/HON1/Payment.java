package com.accenture.ltt.HON1.HON1;

public abstract class Payment {
    protected double amount;
 
    public Payment(double amount) {
        this.amount = amount;
    }
 
    public double getAmount() {
        return amount;
    }
 
    public abstract void processPayment();  
}