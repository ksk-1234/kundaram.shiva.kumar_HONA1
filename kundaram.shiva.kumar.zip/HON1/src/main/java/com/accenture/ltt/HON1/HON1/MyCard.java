package com.accenture.ltt.HON1.HON1;
public interface MyCard {
    void validateCard();
    void chargeCard();
}
