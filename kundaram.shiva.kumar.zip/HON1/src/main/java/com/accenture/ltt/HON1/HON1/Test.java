package com.accenture.ltt.HON1.HON1;
public class Test {
	
	    public static void main(String[] args) {
	        Payment creditCardPayment = new CreditCardPayment(200.0, "1234-5678-9876-5432");
	        creditCardPayment.processPayment();
	 
	        Payment payPalPayment = new PayPalPayment(1000.0, "user@example.com");
	        payPalPayment.processPayment();
	    }

}
